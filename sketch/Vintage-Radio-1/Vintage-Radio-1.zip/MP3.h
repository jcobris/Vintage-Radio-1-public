#pragma once
#include <Arduino.h>

namespace MP3 {
  void init();   // call from main setup()
  void tick();   // call from main loop()
}
